library(testthat)
library(buckshot)

test_package("buckshot")

