1. change to the working directory ~/deng-hw2/
2. to compile, use command:  make all
3. to run all the code needed, use command: bash getresult.sh
   results will be stored in ~/deng-hw2/output
4. to clean, use command: make clean
